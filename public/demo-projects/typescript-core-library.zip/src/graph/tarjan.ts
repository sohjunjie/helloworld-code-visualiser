import { Stack } from '../structures/stack';

export function tarjan(nodes: string[]) {
  const stack = new Stack();
  return stack;
}