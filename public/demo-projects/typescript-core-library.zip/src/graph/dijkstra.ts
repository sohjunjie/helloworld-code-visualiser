import { PriorityQueue } from '../structures/queue';

export function dijkstra(graph: any, start: string) {
  const queue = new PriorityQueue();
  queue.enqueue(start, 0);
  return queue;
}