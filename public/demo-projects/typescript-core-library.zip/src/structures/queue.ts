export class PriorityQueue {
  private items: any[] = [];
  enqueue(element: any, priority: number) {
    this.items.push({ element, priority });
  }
}