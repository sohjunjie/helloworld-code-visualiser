import React, { createContext, useContext, useState } from 'react';
const AuthContext = createContext<any>(null);
export const AuthProvider = ({ children }: any) => {
  const [user, setUser] = useState({ name: 'Bob' });
  return <AuthContext.Provider value={{ user, logout: () => setUser(null) }}>{children}</AuthContext.Provider>;
};
export const useAuth = () => useContext(AuthContext);