import { useState, useEffect } from 'react';
export const useAnalytics = () => {
  const [data] = useState({ visitors: 1040, sales: 320 });
  return { data };
};