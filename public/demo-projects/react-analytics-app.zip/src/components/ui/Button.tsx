import React from 'react';
export const Button = ({ children, onClick }: any) => <button onClick={onClick}>{children}</button>;