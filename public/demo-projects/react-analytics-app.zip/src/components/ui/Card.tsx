import React from 'react';
export const Card = ({ title, children }: any) => <div><h3>{title}</h3>{children}</div>;