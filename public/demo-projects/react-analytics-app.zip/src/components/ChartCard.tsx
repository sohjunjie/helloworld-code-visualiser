import React from 'react';
import { Card } from './ui/Card';

export const ChartCard = ({ data }: { data: any }) => (
  <Card title="Metrics"><div>{JSON.stringify(data)}</div></Card>
);