import React from 'react';
import { ChartCard } from './ChartCard';
import { useAnalytics } from '../hooks/useAnalytics';

export const Dashboard = () => {
  const { data } = useAnalytics();
  return <main><ChartCard data={data} /></main>;
};