import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Button } from './ui/Button';

export const Header = () => {
  const { user, logout } = useAuth();
  return <header><span>{user?.name}</span><Button onClick={logout}>Logout</Button></header>;
};