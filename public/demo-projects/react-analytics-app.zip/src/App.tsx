import React from 'react';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { AuthProvider } from './context/AuthContext';

export const App = () => (
  <AuthProvider>
    <Header />
    <Dashboard />
  </AuthProvider>
);