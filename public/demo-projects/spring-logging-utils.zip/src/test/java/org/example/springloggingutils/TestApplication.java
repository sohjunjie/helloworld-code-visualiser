package org.example.springloggingutils;

import org.example.springloggingutils.annotation.ActionLogging;
import org.example.springloggingutils.annotation.ActionLogging.LogType;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class TestApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestApplication.class, args);
    }

    @ActionLogging(type = LogType.API)
    @GetMapping("/get")
    public String getApi(@RequestHeader("correlationId") String correlationId) {
        return "get api is called";
    }

}
