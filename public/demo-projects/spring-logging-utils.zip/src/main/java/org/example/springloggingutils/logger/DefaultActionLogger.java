package org.example.springloggingutils.logger;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.example.springloggingutils.annotation.ActionLogging;
import org.example.springloggingutils.autoconfig.LoggerAutoConfig.ApiLogFormat;
import org.example.springloggingutils.util.mapper.QueryHelper;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.Tracer;

import java.util.Map;
import java.util.Objects;

@Slf4j
public class DefaultActionLogger implements ActionLogger {

    private final ObjectMapper mapper = new ObjectMapper()
            .setSerializationInclusion(JsonInclude.Include.NON_NULL)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    private final Map<String, ApiLogFormat> logFormat;
    private final LoggingInterceptor loggingInterceptor;

    public DefaultActionLogger(Map<String, ApiLogFormat> logFormat, LoggingInterceptor loggingInterceptor) {
        this.logFormat = logFormat;
        this.loggingInterceptor = loggingInterceptor;
    }

    @Override
    public void logApiRequest(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option) {
        ApiLogFormat apiLogFormat = logFormat.get(logFormatKey);
        if(Objects.isNull(apiLogFormat)) return;
        addTracingTags(tracerSpan,"app.action.logs.before", generateLog(apiLogFormat.getApiRequestFormat(), context, option));
     }

    @Override
    public void logApiResponse(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option) {
        ApiLogFormat apiLogFormat = logFormat.get(logFormatKey);
        if(Objects.isNull(apiLogFormat)) return;
        addTracingTags(tracerSpan,"app.action.logs.after", generateLog(apiLogFormat.getApiResponseFormat(), context, option));
        log.info("spanid is {}", tracerSpan.context().spanId());
    }

    @Override
    public void logApiException(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option) {
        ApiLogFormat apiLogFormat = logFormat.get(logFormatKey);
        if(Objects.isNull(apiLogFormat)) return;
        addTracingTags(tracerSpan,"app.action.logs.after", generateLog(apiLogFormat.getApiExceptionFormat(), context, option));
    }

    @Override
    public void logTraceRequest(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option) {
        ApiLogFormat apiLogFormat = logFormat.get(logFormatKey);
        if(Objects.isNull(apiLogFormat)) return;
        addTracingTags(tracerSpan,"app.action.logs.before", generateLog(apiLogFormat.getTraceRequestFormat(), context, option));
    }

    @Override
    public void logTraceResponse(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option) {
        ApiLogFormat apiLogFormat = logFormat.get(logFormatKey);
        if(Objects.isNull(apiLogFormat)) return;
        addTracingTags(tracerSpan,"app.action.logs.after", generateLog(apiLogFormat.getTraceResponseFormat(), context, option));
        log.info("spanid is {}", tracerSpan.context().spanId());
    }

    @Override
    public void logTraceException(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option) {
        ApiLogFormat apiLogFormat = logFormat.get(logFormatKey);
        if(Objects.isNull(apiLogFormat)) return;
        addTracingTags(tracerSpan,"app.action.logs.after", generateLog(apiLogFormat.getTraceExceptionFormat(), context, option));
    }

    private String generateLog(Map<String, Object> format, Map<String, Object> context, ActionLogging.LogOption option) {

        if(Objects.isNull(format) || format.isEmpty()) return null;

        Map<String, Object> logMessageMap = QueryHelper.doMap(format, QueryHelper.createMappingContext(context));
        return writeAsJson(logMessageMap, option);

    }

    private String writeAsJson(Map<String, Object> obj, ActionLogging.LogOption option) {
        try {
            String message = mapper.writeValueAsString(obj);
            switch (option) {
                case MASK -> message = loggingInterceptor.masking(message);
                case ENCRYPT ->  message =loggingInterceptor.encrypting(message);
            }
            log.info(message);
            return message;
        } catch (JsonProcessingException e) {
            log.warn("Failed to write spring-logging-utils message");
            return null;
        }
    }

    private void addTracingTags(Span tracerSpan, String key, String value) {
        if(StringUtils.isNotBlank(value)) {
            tracerSpan.tag(key, value);
        }
    }

}
