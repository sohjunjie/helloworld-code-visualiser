package org.example.springloggingutils.annotation;

import java.lang.annotation.*;

@Repeatable(ActionLoggingList.class)
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface ActionLogging {

    enum LogType { API, TRACE }
    enum LogOption { MASK, ENCRYPT, NONE }

    ConstantContext[] constContext() default {};
    String responseContextName() default "response";
    String exceptionMessageContextName() default "exceptionMessage";
    String exceptionStackTraceContextName() default "exceptionStackTrace";
    LogType type();
    LogOption option() default LogOption.NONE;

}
