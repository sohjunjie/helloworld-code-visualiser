package org.example.springloggingutils.operator;

import lombok.Setter;
import org.example.springloggingutils.util.mapper.MappingContext;
import org.example.springloggingutils.util.mapper.QueryHelper;

@Setter
public class Query implements Operator<Object> {

    private String path;

    @Override
    public Object execute(MappingContext context) {
        return QueryHelper.readContext(path, context.getDocumentContext());
    }
}
