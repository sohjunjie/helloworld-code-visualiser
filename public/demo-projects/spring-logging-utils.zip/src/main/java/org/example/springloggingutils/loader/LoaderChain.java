package org.example.springloggingutils.loader;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;

@Slf4j
public abstract class LoaderChain {

    @Setter
    protected LoaderChain next;

    public Resource getResource(String path) {
        Resource resource = this.doGetResource(path);
        if(resource == null) {
            if(this.next != null) {
                log.warn("unable to get resource [{}] with {}. Calling next loader", path, this.getClass().getSimpleName());
                return this.next.doGetResource(path);
            }
            log.error("End of resource chain, failed to get resource [{}] with {}", path, this.getClass().getSimpleName());
        }
        return resource;
    }

    protected abstract Resource doGetResource(String path);

}
