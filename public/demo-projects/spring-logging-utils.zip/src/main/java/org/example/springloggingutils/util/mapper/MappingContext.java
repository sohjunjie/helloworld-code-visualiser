package org.example.springloggingutils.util.mapper;

import com.jayway.jsonpath.DocumentContext;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class MappingContext {

    private DocumentContext documentContext;

}
