package org.example.springloggingutils.autoconfig;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.example.springloggingutils.annotation.ActionLogging;
import org.example.springloggingutils.annotation.ActionLoggingList;
import org.example.springloggingutils.config.LoggingConfig;
import org.example.springloggingutils.logger.ActionLogger;
import org.example.springloggingutils.util.LoggingContextHelper;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
@Component
@Aspect
public class AspectAutoConfiguration {

    private final ObjectMapper mapper = new ObjectMapper();
    private final TypeReference<Map<String, Object>> mapTypeRef = new TypeReference<>(){};
    private final ActionLogger actionLogger;
    private final Set<String> supportedApiLogFormat;
    private final String logContextName;
    private final Tracer tracer;

    private final static String LOGSTARTTIME_FIELDNAME = "startTime";
    private final static String LOGENDTIME_FIELDNAME = "endTime";
    private final static String LOGTIMETAKEN_FIELDNAME = "timeTaken";
    private final static String LOGSERVICEMETHODNAME_FIELDNAME = "serviceMethodName";
    private final static String LOGSERVICEFULLMETHODNAME_FIELDNAME = "serviceFullMethodName";
    private final static String LOGTRACEID_FIELDNAME = "traceId";
    private final static String LOGSPANID_FIELDNAME = "spanId";

    public AspectAutoConfiguration(ActionLogger actionLogger, LoggingConfig loggingConfig, Tracer tracer) {
        this.actionLogger = actionLogger;
        this.supportedApiLogFormat = new HashSet<>(loggingConfig.getApiLogFormat().keySet());
        this.logContextName = loggingConfig.getCustomContextName();
        this.tracer = tracer;
    }

    @Around("@annotation(org.example.springloggingutils.annotation.ActionLoggingList)")
    public Object actionLoggingListAdvice(ProceedingJoinPoint joinPoint) throws Throwable {
        ActionLoggingList logger = ((MethodSignature) joinPoint.getSignature()).getMethod().getAnnotation(ActionLoggingList.class);
        String serviceClassName = joinPoint.getSignature().getDeclaringTypeName();
        String serviceMethodName = joinPoint.getSignature().getName();
        String serviceMethodSignature = serviceClassName + "." + serviceMethodName;

        Optional<String> optSupportedFormat = getSupportedLogFormat(serviceMethodSignature);
        if(optSupportedFormat.isEmpty()) {
            log.warn("the invoked method is not a supported api");
            return joinPoint.proceed();
        }

        return handleActionLogger(Arrays.stream(logger.value()).iterator(), joinPoint, optSupportedFormat.get(), serviceClassName, serviceMethodName, serviceMethodSignature);

    }

    @Around("@annotation(org.example.springloggingutils.annotation.ActionLogging)")
    public Object actionLoggingAdvice(ProceedingJoinPoint joinPoint) throws Throwable {

        ActionLogging logger = ((MethodSignature) joinPoint.getSignature()).getMethod().getAnnotation(ActionLogging.class);
        String serviceClassName = joinPoint.getSignature().getDeclaringTypeName();
        String serviceMethodName = joinPoint.getSignature().getName();
        String serviceMethodSignature = serviceClassName + "." + serviceMethodName;

        Optional<String> optSupportedFormat = getSupportedLogFormat(serviceMethodSignature);
        if(!optSupportedFormat.isPresent()) {
            log.warn("the invoked method is not a supported api");
            return joinPoint.proceed();
        }

        Iterator<ActionLogging> actionLoggingIterator = Arrays.stream(new ActionLogging[]{ logger }).iterator();

        return handleActionLogger(actionLoggingIterator, joinPoint, optSupportedFormat.get(), serviceClassName, serviceMethodName, serviceMethodSignature);

    }

    private Map<String, Object> buildInitialLoggingContext(ActionLogging logger, ProceedingJoinPoint joinPoint) {

        Map<String, Object> loggingContext = new HashMap<>();
        java.lang.reflect.Parameter[] parameters = ((MethodSignature) joinPoint.getSignature()).getMethod().getParameters();
        loggingContext.putAll(
                IntStream.range(0, parameters.length)
                        .collect(
                                HashMap::new,
                                (map, idx) -> {
                                    Map<String, Object> context = Collections.singletonMap(parameters[idx].getName(), joinPoint.getArgs()[idx]);
                                    try {
                                        map.putAll(mapper.convertValue(context, mapTypeRef));
                                    } catch (IllegalArgumentException ignored) { }
                                },
                                Map::putAll
                        )
        );
        loggingContext.putAll(
                Arrays.stream(logger.constContext()).collect(
                        HashMap::new,
                        (map, p) -> map.put(p.name(), p.value()),
                        Map::putAll
                )
        );
        return loggingContext;
    }

    private Object handleActionLoggerWithLoggingContext
            (Iterator<ActionLogging> actionLoggingIterator, Span tracerSpan, ActionLogging logger, ProceedingJoinPoint joinPoint, String logFormatKey,
             String serviceClassName, String serviceMethodName, String serviceMethodSignature, Map<String, Object> loggingContext
            ) throws Throwable {

        Map<String, Object> springLoggingContext = new HashMap<>();
        Long startTime = System.currentTimeMillis();
        Long endTime;
        Long timeTaken;

        try {

            springLoggingContext.put(LOGSTARTTIME_FIELDNAME, startTime);
            springLoggingContext.put(LOGSERVICEMETHODNAME_FIELDNAME, serviceMethodName);
            springLoggingContext.put(LOGSERVICEFULLMETHODNAME_FIELDNAME, serviceMethodSignature);
            springLoggingContext.put(LOGTRACEID_FIELDNAME, getSpanTraceId(tracerSpan));
            springLoggingContext.put(LOGSPANID_FIELDNAME, getSpanSpanId(tracerSpan));
            LoggingContextHelper.setSpringLoggingContext(loggingContext, logContextName, springLoggingContext);

            executeBeforeLogging(tracerSpan, logFormatKey, loggingContext, logger.type(), logger.option());

            Object result = handleActionLogger(actionLoggingIterator, joinPoint, logFormatKey, serviceClassName, serviceMethodName, serviceMethodSignature);

            endTime = System.currentTimeMillis();
            timeTaken = endTime - startTime;

            springLoggingContext.put(LOGENDTIME_FIELDNAME, endTime);
            springLoggingContext.put(LOGTIMETAKEN_FIELDNAME, timeTaken);
            LoggingContextHelper.setSpringLoggingContext(loggingContext, logContextName, springLoggingContext);
            loggingContext.putAll(mapper.convertValue(Collections.singletonMap(logger.responseContextName(), result), mapTypeRef));

            executeAfterLogging(tracerSpan, logFormatKey, loggingContext, logger.type(), logger.option());
            return result;

        } catch (Throwable throwable) {
            endTime = System.currentTimeMillis();
            timeTaken = endTime - startTime;

            springLoggingContext.put(LOGENDTIME_FIELDNAME, endTime);
            springLoggingContext.put(LOGTIMETAKEN_FIELDNAME, timeTaken);
            LoggingContextHelper.setSpringLoggingContext(loggingContext, logContextName, springLoggingContext);
            loggingContext.put(logger.exceptionMessageContextName(), throwable.toString());
            loggingContext.put(logger.exceptionStackTraceContextName(), Arrays.stream(throwable.getStackTrace())
                    .map(Objects::toString)
                    .collect(Collectors.toList()));

            executeExceptionLogging(tracerSpan, logFormatKey, loggingContext, logger.type(), logger.option());
            throw throwable;
        }
    }

    private Object handleActionLogger(Iterator<ActionLogging> actionLoggingIterator, ProceedingJoinPoint joinPoint, String logFormatKey, String serviceClassName, String serviceMethodName, String serviceMethodSignature) throws Throwable {

        if(!actionLoggingIterator.hasNext()) {
            return joinPoint.proceed();
        }

        ActionLogging logger = actionLoggingIterator.next();
        Map<String, Object> loggingContext = buildInitialLoggingContext(logger, joinPoint);

        Span newSpan = null;
        try (Tracer.SpanInScope ws = this.tracer.withSpan(tracer.currentSpan())) {
            newSpan = this.tracer.nextSpan().name(serviceMethodSignature);
            newSpan.start();
            return handleActionLoggerWithLoggingContext(
                    actionLoggingIterator, newSpan, logger, joinPoint, logFormatKey,
                    serviceClassName, serviceMethodName, serviceMethodSignature, loggingContext
            );
        } finally {
            if (newSpan != null) {
                newSpan.end();
            }
        }

    }

    private Optional<String> getSupportedLogFormat(String formatKey) {
        return supportedApiLogFormat.stream().filter(pattern -> patternMatches(pattern, formatKey)).findFirst();
    }

    private boolean patternMatches(String pattern, String value) {
        if(StringUtils.isNoneBlank(pattern, value)) {
            return value.matches(pattern);
        }
        return false;
    }

    private String getSpanTraceId(Span span) {
        if(Objects.isNull(span) || Objects.isNull(span.context())) return null;
        return span.context().traceId();
    }

    private String getSpanSpanId(Span span) {
        if(Objects.isNull(span) || Objects.isNull(span.context())) return null;
        return span.context().spanId();
    }

    private void executeBeforeLogging(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogType logType, ActionLogging.LogOption option) {
        switch (logType) {
            case API -> actionLogger.logApiRequest(tracerSpan, logFormatKey, context, option);
            case TRACE -> actionLogger.logTraceRequest(tracerSpan, logFormatKey, context, option);
        }
    }

    private void executeAfterLogging(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogType logType, ActionLogging.LogOption option) {
        switch (logType) {
            case API -> actionLogger.logApiResponse(tracerSpan, logFormatKey, context, option);
            case TRACE -> actionLogger.logTraceResponse(tracerSpan, logFormatKey, context, option);
        }
    }

    private void executeExceptionLogging(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogType logType, ActionLogging.LogOption option) {
        switch (logType) {
            case API -> actionLogger.logApiException(tracerSpan, logFormatKey, context, option);
            case TRACE -> actionLogger.logTraceException(tracerSpan, logFormatKey, context, option);
        }
    }

}
