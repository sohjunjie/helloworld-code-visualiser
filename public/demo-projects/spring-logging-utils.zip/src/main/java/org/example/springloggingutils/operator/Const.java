package org.example.springloggingutils.operator;

import lombok.Setter;
import org.example.springloggingutils.util.mapper.MappingContext;

@Setter
public class Const implements Operator {

    private Object value;

    @Override
    public Object execute(MappingContext context) {
        return this.value;
    }

}
