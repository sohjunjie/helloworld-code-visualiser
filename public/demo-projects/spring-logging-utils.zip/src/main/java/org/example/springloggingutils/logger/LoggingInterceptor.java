package org.example.springloggingutils.logger;

import lombok.AllArgsConstructor;
import org.example.springloggingutils.util.Encryptor;

import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

public class LoggingInterceptor {

    private final List<String> maskPatterns;
    private final String encryptKey;
    private final Pattern multilinePattern;


    public LoggingInterceptor(String encryptKey, List<String> maskPatterns) {
        this.maskPatterns = maskPatterns;
        this.encryptKey = encryptKey;
        this.multilinePattern = Pattern.compile(String.join("|", maskPatterns), Pattern.MULTILINE);
    }

    public String masking(String message) {
        if(maskPatterns == null || maskPatterns.isEmpty()) {
            return message;
        }

        StringBuilder sb = new StringBuilder((message));
        Matcher matcher = multilinePattern.matcher(sb);
        while (matcher.find()) {
            IntStream
                    .rangeClosed(1, matcher.groupCount())
                    .forEach(group -> {
                        if(matcher.group(group) != null) {
                            IntStream
                                    .range(matcher.start(group), matcher.end(group))
                                    .forEach(i -> sb.setCharAt(i, '*'));
                        }
                    });
        }
        return sb.toString();
    }

    public String encrypting(String message) {
        if(maskPatterns == null || maskPatterns.isEmpty() || multilinePattern == null || encryptKey == null || encryptKey.length() != 16) {
            return message;
        }

        StringBuilder sb = new StringBuilder((message));
        Matcher matcher = multilinePattern.matcher(sb);
        List<EncryptData> encryptDataList = new LinkedList<>();
        while (matcher.find()) {
            for(int group = 1; group <= matcher.groupCount(); group++) {
                if(matcher.group(group) != null) {
                    String secretVal = matcher.group(group);
                    String encrypt = Encryptor.encrypt(secretVal, encryptKey);
                    encryptDataList.add(new EncryptData(encrypt, matcher.start(group), matcher.end(group)));

                }
            }
        }

        int offset = 0;
        for(EncryptData data : encryptDataList) {
            sb.replace(data.start + offset, data.end + offset, "");
            sb.insert(data.start + offset, data.encrypt);
            offset += data.encrypt.length() - Math.abs(data.start - data.end);
        }
        return sb.toString();
    }

    @AllArgsConstructor
    public class EncryptData {
        String encrypt;
        int start;
        int end;
    }

}
