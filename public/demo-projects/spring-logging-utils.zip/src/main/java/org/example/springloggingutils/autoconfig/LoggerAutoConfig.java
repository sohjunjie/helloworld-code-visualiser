package org.example.springloggingutils.autoconfig;

import lombok.Builder;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.example.springloggingutils.config.LoggingConfig;
import org.example.springloggingutils.loader.ResourceLoader;
import org.example.springloggingutils.logger.ActionLogger;
import org.example.springloggingutils.logger.DefaultActionLogger;
import org.example.springloggingutils.logger.LoggingInterceptor;
import org.example.springloggingutils.util.mapper.YamlCodec;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Configuration
@EnableConfigurationProperties(LoggingConfig.class)
@Slf4j
public class LoggerAutoConfig {

    @Bean
    public ActionLogger actionLogger(LoggingConfig loggingConfig, ResourceLoader resourceLoader, Tracer tracer) {

        YamlCodec yamlCodec = new YamlCodec();
        Map<String, ApiLogFormat> apiLogFormat = loggingConfig.getApiLogFormat().entrySet().stream().collect(
                HashMap::new, (map, entry) -> {
                    Map<String, Object> apiRequest = initLogMessageFormatStructureMap(yamlCodec, entry.getValue().getApiRequestFormat(), resourceLoader);
                    Map<String, Object> apiResponse = initLogMessageFormatStructureMap(yamlCodec, entry.getValue().getApiResponseFormat(), resourceLoader);
                    Map<String, Object> apiException = initLogMessageFormatStructureMap(yamlCodec, entry.getValue().getApiExceptionFormat(), resourceLoader);
                    Map<String, Object> traceRequest = initLogMessageFormatStructureMap(yamlCodec, entry.getValue().getTraceRequestFormat(), resourceLoader);
                    Map<String, Object> traceResponse = initLogMessageFormatStructureMap(yamlCodec, entry.getValue().getTraceResponseFormat(), resourceLoader);
                    Map<String, Object> traceException = initLogMessageFormatStructureMap(yamlCodec, entry.getValue().getTraceExceptionFormat(), resourceLoader);

                    map.put(entry.getKey(),
                            ApiLogFormat.builder()
                                    .apiRequestFormat(apiRequest)
                                    .apiResponseFormat(apiResponse)
                                    .apiExceptionFormat(apiException)
                                    .traceRequestFormat(traceRequest)
                                    .traceResponseFormat(traceResponse)
                                    .traceExceptionFormat(traceException)
                                    .build()
                    );

                },
                Map::putAll
        );

        return new DefaultActionLogger(
                apiLogFormat,
                new LoggingInterceptor(loggingConfig.getEncryptKey(), loggingConfig.getMaskPatterns())
        );

    }

    private Map<String, Object> initLogMessageFormatStructureMap(YamlCodec yaml, LoggingConfig.LogMessageFormat format, ResourceLoader resourceLoader) {
        if(Objects.isNull(format)) return Collections.emptyMap();

        String filepath = format.getStructureFile();
        if(StringUtils.isBlank(filepath)) return Collections.emptyMap();

        Resource r = resourceLoader.getResource(filepath);
        if(r != null) {
            try {
                return yaml.loadMap(r.getInputStream());
            } catch (FileNotFoundException e) {
                log.error("Rule file {} not found", filepath);
            } catch (IOException e) {
                log.error("Failed to load rule file {}", filepath);
            }
        }
        return Collections.emptyMap();
    }

    @Getter
    @Builder
    public static class ApiLogFormat {
        private Map<String, Object> apiRequestFormat;
        private Map<String, Object> apiResponseFormat;
        private Map<String, Object> apiExceptionFormat;
        private Map<String, Object> traceRequestFormat;
        private Map<String, Object> traceResponseFormat;
        private Map<String, Object> traceExceptionFormat;
    }

}
