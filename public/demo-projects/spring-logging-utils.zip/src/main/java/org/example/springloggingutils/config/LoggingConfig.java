package org.example.springloggingutils.config;


import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@ConfigurationProperties(prefix = "spring-logging-utils")
@Getter
@Setter
public class LoggingConfig {

    private String encryptKey;
    private List<String> maskPatterns = Collections.emptyList();
    private String customContextName = "spring-logging";
    private Map<String, ApiLogFormat> apiLogFormat = Collections.emptyMap();

    @Getter
    @Setter
    public static class ApiLogFormat {
        private LogMessageFormat apiRequestFormat;
        private LogMessageFormat apiResponseFormat;
        private LogMessageFormat apiExceptionFormat;
        private LogMessageFormat traceRequestFormat;
        private LogMessageFormat traceResponseFormat;
        private LogMessageFormat traceExceptionFormat;
    }

    @Getter
    @Setter
    public static class LogMessageFormat {
        private String structureFile;
    }

}
