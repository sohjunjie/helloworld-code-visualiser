package org.example.springloggingutils.annotation;

public @interface ConstantContext {
    String name();
    String value();
}
