package org.example.springloggingutils.loader;

import org.springframework.core.io.Resource;

public interface ResourceLoader {

    Resource getResource(String path);

}
