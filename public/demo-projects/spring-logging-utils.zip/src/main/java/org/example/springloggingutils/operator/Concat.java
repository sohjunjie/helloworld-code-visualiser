package org.example.springloggingutils.operator;

import lombok.Setter;
import org.apache.commons.lang3.ArrayUtils;
import org.example.springloggingutils.util.mapper.MappingContext;

import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Collectors;

@Setter
public class Concat implements Operator<String> {

    private Operator[] from;
    private String separator = "";

    @Override
    public String execute(MappingContext context) {
        return ArrayUtils.isEmpty(this.from) ? null : Arrays.stream(this.from)
                .map(operator -> operator.execute(context))
                .filter(Objects::nonNull)
                .map(Objects::toString)
                .collect(Collectors.joining(this.separator));
    }
}
