package org.example.springloggingutils.util.mapper;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import org.apache.commons.lang3.StringUtils;
import org.example.springloggingutils.operator.Operator;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class QueryHelper {

    private QueryHelper() {
        throw new IllegalStateException("New instance of QueryHelper class is illegal");
    }

    public static MappingContext createMappingContext(Object context) {
        DocumentContext ctxt = JsonPath.parse(context);
        return MappingContext.builder()
                .documentContext(ctxt)
                .build();
    }

    public static Object readContext(String path, DocumentContext ctxt) {
        if(!isValid(path)) return path;
        try {
            return ctxt.read(path);
        } catch (PathNotFoundException e) {
            return null;
        }
    }

    public static Object excludeObjectPath(Object obj, List<String> excludePaths) {
        DocumentContext ctxt = JsonPath.parse(obj);
        excludePaths.forEach(excludePath -> ctxt.delete(JsonPath.compile(excludePath)));
        return ctxt.read("$");
    }

    private static boolean isValid(String jsonPath) {
        String trimPath = StringUtils.trim(jsonPath);
        return StringUtils.equals(trimPath, "$") || StringUtils.startsWith(trimPath, "$.") && !"$.".contentEquals(trimPath);
    }

    public static Map<String, Object> doMap(Map<String, Object> source, MappingContext context) {
        return doContextMap(source, context);
    }

    private static Map<String, Object> doContextMap(Map<String, Object> source, MappingContext context) {
        return source.entrySet().stream().collect(
                HashMap::new, (map, entry) -> {
                    if(entry.getValue() instanceof Map) {
                        map.put(entry.getKey(), doContextMap((Map<String, Object>) entry.getValue(), context));
                    }
                    else if (entry.getValue() instanceof List) {
                        map.put(entry.getKey(), doContextMap((List) entry.getValue(), context));
                    }
                    else if (entry.getValue() instanceof Operator) {
                        map.put(entry.getKey(), ((Operator) entry.getValue()).execute(context));
                    }
                    else {
                        map.put(entry.getKey(), entry.getValue());
                    }
                }, Map::putAll
        );
    }

    private static List<Object> doContextMap(List<Object> source, MappingContext context) {
        return source.stream().map(item -> {
            if(item instanceof Map) {
                return doContextMap((Map<String, Object>) item, context);
            }
            if(item instanceof List) {
                return doContextMap((List<Object>) item, context);
            }
            if(item instanceof Operator<?>) {
                return ((Operator) item).execute(context);
            }
            return item;
        }).collect(Collectors.toList());
    }

}
