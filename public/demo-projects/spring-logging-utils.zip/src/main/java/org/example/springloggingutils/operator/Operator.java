package org.example.springloggingutils.operator;

import org.example.springloggingutils.util.mapper.MappingContext;

public interface Operator<T> {
    T execute(MappingContext context);
}
