package org.example.springloggingutils.operator;

import lombok.Setter;
import org.example.springloggingutils.util.mapper.MappingContext;
import org.example.springloggingutils.util.mapper.QueryHelper;

import java.util.List;

@Setter
public class ExcludeFields implements Operator<Object> {

    Operator<Object> from;
    List<String> paths;

    @Override
    public Object execute(MappingContext context) {
        Object obj = from.execute(context);
        return QueryHelper.excludeObjectPath(obj, paths);
    }

}
