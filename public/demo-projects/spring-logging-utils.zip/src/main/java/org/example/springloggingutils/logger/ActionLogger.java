package org.example.springloggingutils.logger;

import org.example.springloggingutils.annotation.ActionLogging;
import org.springframework.cloud.sleuth.Span;

import java.util.Map;

public interface ActionLogger {

    void logApiRequest(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option);

    void logApiResponse(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option);

    void logApiException(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option);

    void logTraceRequest(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option);

    void logTraceResponse(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option);

    void logTraceException(Span tracerSpan, String logFormatKey, Map<String, Object> context, ActionLogging.LogOption option);

}
