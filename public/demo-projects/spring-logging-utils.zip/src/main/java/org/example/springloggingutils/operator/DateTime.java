package org.example.springloggingutils.operator;

import lombok.Setter;
import org.example.springloggingutils.util.mapper.MappingContext;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Setter
public class DateTime implements Operator<String> {

    private Operator<Long> from;
    private String pattern;
    private String zoneId;


    @Override
    public String execute(MappingContext context) {
        Long timeMs = from.execute(context);
        return Instant.ofEpochMilli(timeMs)
                .atZone(ZoneId.of(zoneId))
                .format(DateTimeFormatter.ofPattern(pattern));
    }

}
