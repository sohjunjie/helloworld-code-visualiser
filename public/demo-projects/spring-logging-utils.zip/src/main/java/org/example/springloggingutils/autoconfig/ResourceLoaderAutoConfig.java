package org.example.springloggingutils.autoconfig;

import lombok.extern.slf4j.Slf4j;
import org.example.springloggingutils.loader.ChainedResourceLoader;
import org.example.springloggingutils.loader.ClassPathLoaderChain;
import org.example.springloggingutils.loader.LoaderChain;
import org.example.springloggingutils.loader.ResourceLoader;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class ResourceLoaderAutoConfig {

    @Bean
    @ConditionalOnMissingBean
    public ResourceLoader chainedResourceLoader(List<LoaderChain> loaderChains) {
        String loaderClasses = loaderChains.stream()
                .map(e -> {
                    if(e != null) {
                        return e.getClass().getName();
                    }
                    return "null";
                })
                .collect(Collectors.joining(","));
        log.info("Creating ChainedResourceLoader with loaders: [{}]", loaderClasses);
        return new ChainedResourceLoader(loaderChains);
    }

    @Bean
    @Order(Ordered.LOWEST_PRECEDENCE)
    public LoaderChain classPathLoaderChain() {
        return new ClassPathLoaderChain();
    }

}
