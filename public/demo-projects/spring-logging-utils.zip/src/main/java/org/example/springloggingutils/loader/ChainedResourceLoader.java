package org.example.springloggingutils.loader;

import org.springframework.core.io.Resource;

import java.util.List;
import java.util.stream.IntStream;

public class ChainedResourceLoader implements ResourceLoader {

    private final LoaderChain firstLoader;

    public ChainedResourceLoader(List<LoaderChain> loaderChains) {
        this.firstLoader = loaderChains.get(0);
        if(loaderChains.size() > 1) {
            IntStream.range(0, loaderChains.size() - 1).boxed().forEach(i -> loaderChains.get(i).setNext(loaderChains.get(i + 1)));
        }
    }

    @Override
    public Resource getResource(String path) { return this.firstLoader.getResource(path); }

}
