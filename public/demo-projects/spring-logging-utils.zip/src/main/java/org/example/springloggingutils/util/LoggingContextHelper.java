package org.example.springloggingutils.util;

import java.util.HashMap;
import java.util.Map;

public class LoggingContextHelper {

    public static void setSpringLoggingContext(Map<String, Object> context, String contextName, Map<String, Object> subContext) {
        if(context.containsKey(contextName) && context.get(contextName) instanceof Map) {
            ((Map) context.get(contextName)).putAll(subContext);
        } else {
            context.put(contextName, new HashMap<>(subContext));
        }
    }

}
