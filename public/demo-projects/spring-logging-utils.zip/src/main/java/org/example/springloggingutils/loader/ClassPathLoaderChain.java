package org.example.springloggingutils.loader;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@Slf4j
public class ClassPathLoaderChain extends LoaderChain {
    @Override
    protected Resource doGetResource(String path) {
        log.info("Getting classpath resource {}", path);
        Resource resource = new ClassPathResource(path);
        if(!resource.exists()) {
            return null;
        }
        return resource;
    }
}
