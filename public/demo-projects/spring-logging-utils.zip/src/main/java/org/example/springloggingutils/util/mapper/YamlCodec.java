package org.example.springloggingutils.util.mapper;

import org.example.springloggingutils.operator.*;
import org.yaml.snakeyaml.TypeDescription;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;
import org.yaml.snakeyaml.representer.Representer;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class YamlCodec {

    private static Map<String, Class> typeAlias = new HashMap<>();
    private Yaml yml;

    static {
        typeAlias.put("!query", Query.class);
        typeAlias.put("!datetime", DateTime.class);
        typeAlias.put("!const", Const.class);
        typeAlias.put("!concat", Concat.class);
        typeAlias.put("!exclude", ExcludeFields.class);
    }

    public YamlCodec() {
        Constructor constructor = new Constructor(HashMap.class);
        Representer representer = new Representer();
        typeAlias.forEach((key, value) -> constructor.addTypeDescription(new TypeDescription(value, key)));
        this.yml = new Yaml(constructor, representer);
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> loadMap(String yaml) { return this.yml.loadAs(yaml, Map.class); }

    @SuppressWarnings("unchecked")
    public Map<String, Object> loadMap(InputStream yaml) { return this.yml.loadAs(yaml, Map.class); }

}
