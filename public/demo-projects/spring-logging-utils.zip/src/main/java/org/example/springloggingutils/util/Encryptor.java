package org.example.springloggingutils.util;

import lombok.extern.slf4j.Slf4j;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

@Slf4j
public class Encryptor {

    private static Cipher cipher;
    static {
        try {
            cipher = Cipher.getInstance("AES");
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            log.error("unable to create cipher, {}", e.getMessage());
        }
    }

    private Encryptor() {
        throw new IllegalStateException("New instance of Encryptor class is illegal");
    }

    private static String toHexString(byte[] bytes) { return DatatypeConverter.printHexBinary(bytes); }

    public static String encrypt(String text, String keyStr) {
        try {
            if (keyStr == null || keyStr.length() != 16) {
                throw new InvalidKeyException("bad aes key configured");
            }
            Key aesKey = new SecretKeySpec(keyStr.getBytes(), "AES");
            cipher.init(Cipher.ENCRYPT_MODE, aesKey);
            return toHexString(cipher.doFinal(text.getBytes()));
        } catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
            log.error("fallback to masking due to failure in encryption: {}", e.getMessage());
            return text.replaceAll("\\S", "*");
        }
    }

}
