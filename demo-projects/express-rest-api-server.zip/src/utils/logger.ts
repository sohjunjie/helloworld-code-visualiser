export class Logger {
  static info(...args: any[]) {
    console.log('[INFO]', ...args);
  }
}