import { Logger } from '../utils/logger';

export const authMiddleware = (req: any, res: any, next: any) => {
  Logger.info('Authenticating request');
  next();
};