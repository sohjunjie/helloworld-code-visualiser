import { Router } from 'express';
import { getUser, createUser } from '../controllers/user.controller';

export const userRouter = Router();
userRouter.get('/:id', getUser);
userRouter.post('/', createUser);