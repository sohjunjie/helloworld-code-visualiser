import { UserService } from '../services/user.service';

const userService = new UserService();
export const getUser = async (req: any, res: any) => {
  const user = await userService.findUserById(req.params.id);
  res.json(user);
};
export const createUser = async (req: any, res: any) => {
  const user = await userService.createUser(req.body);
  res.json(user);
};