import { Logger } from '../utils/logger';

export const connectDatabase = () => {
  Logger.info('Database connected successfully');
};