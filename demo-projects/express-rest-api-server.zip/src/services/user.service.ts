import { UserModel } from '../models/user.model';
import { Logger } from '../utils/logger';

export class UserService {
  async findUserById(id: string) {
    Logger.info('Fetching user', id);
    return UserModel.findById(id);
  }
  async createUser(data: any) {
    return UserModel.create(data);
  }
}