export interface User {
  id: string;
  name: string;
  email: string;
}

export const UserModel = {
  findById: (id: string) => ({ id, name: 'Alice', email: 'alice@example.com' }),
  create: (data: any) => ({ id: '123', ...data }),
};