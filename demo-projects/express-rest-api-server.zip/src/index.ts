import express from 'express';
import { userRouter } from './routes/user.routes';
import { authMiddleware } from './middleware/auth.middleware';
import { connectDatabase } from './services/db.service';

const app = express();
connectDatabase();
app.use('/api/users', authMiddleware, userRouter);
app.listen(3000);